require 'ruble'

bundle do |bundle|
  bundle.author = ''
  bundle.copyright = ""
  bundle.display_name = t(:bundle_name)
  bundle.description = "Javascript bundle for RadRails, ported from the TextMate bundle"
  bundle.repository = ""
  
end
