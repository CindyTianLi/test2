# Math bundle for Aptana Studio

A bundle to enable related commands in Aptana Studio. Ported from a TextMate bundle.

## Authors

* TextMate Contributors
* Modifications by Aptana

## License

This bundle is licensed under the TextMate license, available here:

* [TextMate license](http://svn.textmate.org/trunk/LICENSE)

## Bugs/Requests

* You can [report a bug or request a feature here](http://github.com/aptana/math.ruble/issues)