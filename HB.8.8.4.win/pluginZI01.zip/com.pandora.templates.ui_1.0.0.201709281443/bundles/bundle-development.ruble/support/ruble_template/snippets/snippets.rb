require 'ruble'

snippet "Sample Snippet" do |snip|
  snip.trigger = "sample"
  snip.expansion = "sample_snippet"
end

# Use Commands > Bundle Development > Insert Bundle Section > Snippet
# to easily add new snippets