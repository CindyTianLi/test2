require 'ruble'

template t(:css_template) do |t|
  t.filetype = "*.css"
  t.location = "templates/template.css"
end