require 'ruble'

# Commenting out template code until we have actual default content to use
#template "JSON Template" do |t|
#  t.filetype = "*.json"
#  t.location = "templates/template.json"
#end