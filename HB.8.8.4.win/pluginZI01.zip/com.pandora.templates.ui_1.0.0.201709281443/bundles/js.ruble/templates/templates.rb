require 'ruble'

template "JavaScript Template" do |t|
  t.filetype = "*.js"
  t.location = "templates/template.js"
end